package com.api.usermanagement.controller;

import com.api.usermanagement.dto.ApiResponse;
import com.api.usermanagement.dto.UserDto;
import com.api.usermanagement.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    public ResponseEntity<ApiResponse<UserDto.Response>> createUser(
            @Valid @RequestBody UserDto.CreateRequest request) {
        UserDto.Response user = userService.createUser(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("User created successfully", user));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<UserDto.Response>>> getAllUsers() {
        List<UserDto.Response> users = userService.getAllUsers();
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully", users));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<UserDto.Response>> getUserById(@PathVariable Long id) {
        UserDto.Response user = userService.getUserById(id);
        return ResponseEntity.ok(ApiResponse.success("User retrieved successfully", user));
    }

    @PostMapping("/{userId}/groups/{groupId}")
    public ResponseEntity<ApiResponse<UserDto.Response>> addUserToGroup(
            @PathVariable Long userId,
            @PathVariable Long groupId) {
        UserDto.Response user = userService.addUserToGroup(userId, groupId);
        return ResponseEntity.ok(ApiResponse.success("User added to group successfully", user));
    }

    @DeleteMapping("/{userId}/groups/{groupId}")
    public ResponseEntity<ApiResponse<UserDto.Response>> removeUserFromGroup(
            @PathVariable Long userId,
            @PathVariable Long groupId) {
        UserDto.Response user = userService.removeUserFromGroup(userId, groupId);
        return ResponseEntity.ok(ApiResponse.success("User removed from group successfully", user));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(ApiResponse.success("User deleted successfully", null));
    }
}
