package com.api.usermanagement.controller;

import com.api.usermanagement.dto.ApiResponse;
import com.api.usermanagement.dto.GroupDto;
import com.api.usermanagement.service.GroupService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/groups")
@RequiredArgsConstructor
public class GroupController {

    private final GroupService groupService;

    @PostMapping
    public ResponseEntity<ApiResponse<GroupDto.Response>> createGroup(
            @Valid @RequestBody GroupDto.CreateRequest request) {
        GroupDto.Response group = groupService.createGroup(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Group created successfully", group));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<GroupDto.Response>>> getAllGroups() {
        List<GroupDto.Response> groups = groupService.getAllGroups();
        return ResponseEntity.ok(ApiResponse.success("Groups retrieved successfully", groups));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<GroupDto.Response>> getGroupById(@PathVariable Long id) {
        GroupDto.Response group = groupService.getGroupById(id);
        return ResponseEntity.ok(ApiResponse.success("Group retrieved successfully", group));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteGroup(@PathVariable Long id) {
        groupService.deleteGroup(id);
        return ResponseEntity.ok(ApiResponse.success("Group deleted successfully", null));
    }
}
